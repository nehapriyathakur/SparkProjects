##Stock Analysis
___
	StockAnalysis is a Spark application predominently using Spark SQL used to process Stock data and generate some useful insights from it 
	e.g. average closing price,max and min closing price etc.We are providing Stock details in CSV format(can be downloaded from yahoo finance) 
	to our application as input and reading them using Spark SQL with inbuilt CSV reader.Using various Spark transformations like join,
	orderBy,groupBy to generate all the required KPIs.Spark level performance optimizations involved like caching,ORC format,resource tuning etc. 
	 
####	<u>Command	To Run Job</u>
<ul>
<li>spark-submit \ </li>
<li>--master yarn-cluster \</li>
<li>--num-executors 8 \</li>
<li>--executor-cores 4 \</li>
<li>--executor-memory 5G \</li>
<li>--driver-memory 5G \</li>
<li>--conf "spark.serializer=org.apache.spark.serializer.KryoSerializer" \</li>
<li>--class com.exercise.stock.StockAnalysis \ </li>
<li>StockAnalysis.jar</li>
</ul>