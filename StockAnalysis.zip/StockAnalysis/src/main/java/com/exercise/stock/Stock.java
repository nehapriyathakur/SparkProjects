package com.exercise.stock;

import java.io.Serializable;

public class Stock implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String date;
	private double open;
	private double high;
	private double low;
	private double close;
	private double adjClose;
	private long volume;
	
	
	public Stock(String date, String open, String high, String low, String close, String adjClose, String volume) {
		super();
		this.date = date;
		this.open = Double.parseDouble(open);
		this.high = Double.parseDouble(high);
		this.low = Double.parseDouble(low);
		this.close = Double.parseDouble(close);
		this.adjClose = Double.parseDouble(adjClose);
		this.volume = Long.parseLong(volume);
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public double getOpen() {
		return open;
	}
	public void setOpen(double open) {
		this.open = open;
	}
	public double getHigh() {
		return high;
	}
	public void setHigh(double high) {
		this.high = high;
	}
	public double getLow() {
		return low;
	}
	public void setLow(double low) {
		this.low = low;
	}
	public double getClose() {
		return close;
	}
	public void setClose(double close) {
		this.close = close;
	}
	public double getAdjClose() {
		return adjClose;
	}
	public void setAdjClose(double adjClose) {
		this.adjClose = adjClose;
	}
	public long getVolume() {
		return volume;
	}
	public void setVolume(long volume) {
		this.volume = volume;
	}
}
