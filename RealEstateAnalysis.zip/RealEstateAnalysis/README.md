##Real Estate Analysis
___
	Based on historical real estate data various user queries can be addressed e.g.city wise price, property sale trends etc. using Spark. Sample real estate date for California,
	US is being used as input for this use case and they are primarily stored in HDFS and processing those data with Spark Core with addressing key performance measures.
	Various spark transformations like filter, map,mapToPair etc. are involved for this implementation.	
	 
####	<u>Command	To Run Job</u>
<ul>
<li>spark-submit \ </li>
<li>--master yarn-cluster \</li>
<li>--num-executors 8 \</li>
<li>--executor-cores 4 \</li>
<li>--executor-memory 5G \</li>
<li>--driver-memory 5G \</li>
<li>--conf "spark.serializer=org.apache.spark.serializer.KryoSerializer" \</li>
<li>--class com.spark.exercise.RealEstateAnalysis \ </li>
<li>RealEstateAnalysis.jar <..state.csv></li>
</ul>