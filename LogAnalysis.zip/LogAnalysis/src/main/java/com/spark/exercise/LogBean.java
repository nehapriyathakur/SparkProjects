package com.spark.exercise;

import java.io.Serializable;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class LogBean implements Serializable {

	private static final long serialVersionUID = 1L;

	private DateTime datetime;
	private String ipAddress;
	private int responseCode;
	private long contentSize;
	private String endpoint;

	public LogBean(String datetime, String ipAddress, String endpoint, String responseCode, String contentSize) {
		
		super();
		this.ipAddress = ipAddress;
		this.endpoint = endpoint;
		this.responseCode = Integer.parseInt(responseCode);
		this.contentSize = Long.parseLong(contentSize);
		try{
		DateTimeFormatter dateFormat = DateTimeFormat.forPattern("dd/MMM/yyyy:HH:mm:ss");
		this.datetime = dateFormat.parseDateTime(datetime);
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public DateTime getDatetime() {
		return datetime;
	}

	public void setDatetime(DateTime datetime) {
		this.datetime = datetime;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public int getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}

	public long getContentSize() {
		return contentSize;
	}

	public void setContentSize(long contentSize) {
		this.contentSize = contentSize;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}
}
