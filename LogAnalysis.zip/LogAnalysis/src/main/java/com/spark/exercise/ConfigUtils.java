package com.spark.exercise;

import java.io.File;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class ConfigUtils {

	public static Config getConfig(String path) {
		Config config = null;
		try {
			File configFile = new File(path);
			config = ConfigFactory.parseFile(configFile).getConfig("log");
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		return config;
	}
}
