##Log Analysis
___
	Loganalysis is a Spark application to process production level server logs and harnesses the power of that data. After processing the resultant data
	can be used for various monitoring applications. The common apache access log is used for this use case and the log contains various parameters like timestamp,
	IP address, error code etc. This application process those logs and provides the number of KPIs e.g. identical error occurred for a
	particular time,IPAddress that has accessed the server more than 10 times etc.. We are using mapToPair to form pairRdd based on datetime and doing reduceByKey to generate the expected outcome. 
	Performance optimization techniques involved like Spark Serialization,Spark Resource tuning etc.
	 
####	<u>Command	To Run Job</u>
<ul>
<li>spark-submit \ </li>
<li>--master yarn-cluster \</li>
<li>--num-executors 8 \</li>
<li>--executor-cores 4 \</li>
<li>--executor-memory 5G \</li>
<li>--driver-memory 5G \</li>
<li>--conf "spark.serializer=org.apache.spark.serializer.KryoSerializer" \</li>
<li>--class com.spark.exercise.LogAnalysis \ </li>
<li>LogAnalysis.jar 'log file location'</li>
</ul>