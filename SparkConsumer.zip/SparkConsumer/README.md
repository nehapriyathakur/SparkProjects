##Spark Kafka Consumer
___
	Primary objective of this application is to develop a Spark Streaming application working as a Consumer to consume Kafka messages in real-time. Kafka Producer 
		is supposed to produce CSV format data and will be transformed by Spark DataFrame APIs.Input data contains country-specific weather records like humidity, 
		temperature, wind speed etc. We are also using one small dataset contains country, state, and country code and it's being used as a cached dataset.
		The implementation involves joining the incoming Kafka dataset with cached data to produce state-level weather report. A number of performance optimizations
		involved in transformation level e.g.repatitioning, broadcast joins orc file format etc.
	 
####	<u>Command	To Run Job</u>
<ul>
<li>spark-submit \ </li>
<li>--master yarn-cluster \</li>
<li>--num-executors 8 \</li>
<li>--executor-cores 4 \</li>
<li>--executor-memory 5G \</li>
<li>--driver-memory 5G \</li>
<li>--conf "spark.streaming.backpressure.enabled=true" \</li>
<li>--conf "spark.serializer=org.apache.spark.serializer.KryoSerializer" \</li>
<li>--class com.spark.exercise.KafkaSparkConsumer \ </li>
<li>KafkaSparkConsumer.jar <..geoRegion.csv></li>
</ul>